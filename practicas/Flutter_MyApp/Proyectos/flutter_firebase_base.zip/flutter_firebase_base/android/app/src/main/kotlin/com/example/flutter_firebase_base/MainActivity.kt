package com.example.flutter_firebase_base

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
